import java.util.ArrayList;
import java.util.Scanner;

public class bainary_add {
	static Scanner scanner = new Scanner( System.in );
	static ArrayList<String> bainary_number_list = new ArrayList<String>();
	static String input ;
	static int i=0;
	
	public static void main(String[] args) {
		System.out.println("Press Equal(=) & enter for Result\n\n");
		System.out.print("Enter 1st number: ");
		for(int inpu_number=1;;) {
			input=scanner.nextLine();
			if(cheek_input()==true) {
				if(input.equals("=")) {
					result();
					bainary_number_list.removeAll(bainary_number_list);
					break;
				}else {
					bainary_number_list.add(input);
					inpu_number++;
					System.out.print("Enter " +inpu_number+"  :");
				}
			}
	
		}
	}
	private static boolean cheek_input() {
		if(input.equals("=")) {
			return true;
		}
		for(int j=0;input.length()>j;j++) {
			if(input.charAt(j)=='0'||input.charAt(j)=='1') {
			}else {
				System.out.println("Your Binary Number Is incorrect! enter again...");
				return false;
			}
		}
		return true;
				
	}
	private static void result() {
		String result;
		int fastnumber_Size,secoundnumber_Size;
		result=bainary_number_list.get(0);
		//System.out.println(bainary_number_list.size()-1);
		for(int j=1;j<bainary_number_list.size();j++) {
			//System.out.println("bainary_number_list sixe:"+bainary_number_list.size()+"= "+bainary_number_list);
			if(bainary_number_list.get(j).equals("")) {
				continue;
			}else {
				String abc;
				fastnumber_Size=result.length();
				secoundnumber_Size=bainary_number_list.get(j).length();
				abc=result;
				result=calclution(fastnumber_Size-1,secoundnumber_Size-1,result,bainary_number_list.get(j));
				
			
				System.out.println( abc+" + " + bainary_number_list.get(j)+" = "+result);
				
				
			}
		}
		System.out.println("\nTotal result= "+result);
	}
	
	
	
	
	private static String calclution(int fastnumber_Size, int secoundnumber_Size, String fast_number, String secound_number) {
		ArrayList<String> main_result=  new ArrayList<String>();
		String extra="0";
		int i;
		if(fastnumber_Size>secoundnumber_Size||fastnumber_Size==secoundnumber_Size) {
			
		}else {
			String swap="";
			int swp;
			swp=fastnumber_Size;
			fastnumber_Size=secoundnumber_Size;
			secoundnumber_Size=swp;
			swap=fast_number;
			fast_number=secound_number;
			secound_number=swap;	
		}
		
			for(i=fastnumber_Size;i!=-1;i--) {
				if(fast_number.charAt(i)=='1'&&secound_number.charAt(secoundnumber_Size)=='1') {
					if(extra.equals("1")) {
						main_result.add(0,"1");
						extra="1";
					}else {
						main_result.add(0,"0");
						extra="1";
					}
				}
				else if(fast_number.charAt(i)=='1'&&secound_number.charAt(secoundnumber_Size)=='0') {
					if(extra.equals("1")) {
						main_result.add(0,"0");
						extra="1";
					}else {
						main_result.add(0,"1");
						extra="0";
					}
				}
				else if(fast_number.charAt(i)=='0'&&secound_number.charAt(secoundnumber_Size)=='1') {
					if(extra.equals("1")) {
						main_result.add(0,"0");
						extra="1";
					}else {
						main_result.add(0,"1");
						extra="0";
					}
				}
				else if(fast_number.charAt(i)=='0'&&secound_number.charAt(secoundnumber_Size)=='0') {
					if(extra.equals("1")) {
						main_result.add(0,"1");
						extra="0";
					}else {
						main_result.add(0,"0");
						extra="0";
					}
				}
			/*	System.out.println(i);
				System.out.println(secoundnumber_Size);
				System.out.println(fast_number.charAt(i));
				System.out.println(secound_number.charAt(secoundnumber_Size));
				System.out.println("extra"+extra);
				System.out.println(main_result);
				System.out.println(secound_number);*/
				
				
				if(i==0 && extra.equals("1")) {
					main_result.add(0,"1");
					//System.out.println("extra added");
				}
				
				if(secoundnumber_Size!=-1) {
					secoundnumber_Size--;
				}
				if(secoundnumber_Size==-1) {
					secound_number="0";
					secoundnumber_Size=0;
					//System.out.println(secound_number);
				}
			
			//System.out.println(i);
		}
		
		
	
		//System.out.println(main_result);
		String resultt="";
		for(String add:main_result ) {
			resultt+=add;
		}
		return resultt;
		
	}

}
